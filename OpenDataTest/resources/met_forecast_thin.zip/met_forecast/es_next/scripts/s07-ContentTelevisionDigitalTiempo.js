// FUNCIONES PARA PAGINACI�N DE CAPAS //
var x;
var numElem;
var numCapasElem;

function inicializarCapas() {
	document.getElementById('divTexto1').style.posHeight = 204;
	var alto = document.getElementById('divTexto2').scrollHeight;
	altoTotal = document.getElementById('divTexto1').style.posHeight;
	var elementos = Math.ceil(alto/altoTotal);
	numElem= elementos;
	y=0;
}

function inicializar() {
	numElem= 0;
	numCapasElem= 1;

	inicializarCapas();

	x= 1;
	if (numElem > 1) {
		document.getElementById("pag_txt").innerHTML= x + " / " + numElem;
		document.getElementById("flechas").style.visibility= "visible";
	}else{
		document.getElementById("pag_txt").innerHTML= numElem;
	}
}

/*************** Paginacion en capas ************/
var relleno = true;

function mover_datos(sentidoDerecha,des){
	inc=(des)?des:numCapasElem;
	if(inc==numCapasElem)
		y=Math.floor(y/numCapasElem)*numCapasElem;
	if(sentidoDerecha==null){
		;
	} else {
		if(!sentidoDerecha){
			y=y-inc;
			if(y<1)
			y=0;
		} else {
			if(sentidoDerecha){
				y=y+inc;
				if(y>numElem)
					y=numElem-inc;
			}
		}
	}
	
	yvis=y;
	ind=0;

	if(inc==numCapasElem&&relleno){
		if(yvis+numCapasElem>numElem){
			yvis=numElem-numCapasElem;
			if(yvis<0){
				yvis=0;
			}
		}
	}
	
	indiceScroll=yvis;
	var salir=false;
	for(i=0; i<numCapasElem&&i<numElem; i++){
		if(yvis+i>=numElem){
			ind=(yvis+i)-numElem;
			if(!relleno)
				salir=true;
		}
		else
			ind=yvis+i;
			print_linea(ind);
	}
}

function print_linea( ind_array ) {
	comdet.style.posTop = - ind_array * altoTotal;
}
/*************** Fin Paginacion en capas ************/

// funcion para cambiar imagen dependiendo del foco
function carga_img(img_num)
{
	var rtc='/contenidos/recurso_tecnico/tdtrtc/es_rtc/images/';

	for(i=0;i<4;i++)
	{
		if(i==posicion)
		{
			document.getElementById('a' + i).style.visibility = 'visible';
			document.getElementById('a' + i).src = rtc+'s07-okMover_btn.gif';
			document.getElementById('menu' + i).style.background = 'url('+rtc+'s07-opcOn.gif)';
			document.getElementById('menu' + i).style.color = '#ffffff';
		} else {
			document.getElementById('a' + i).src = rtc+'s07-op'+(i+1)+'_btn.gif';
			document.getElementById('menu' + i).style.color = '#575656';
			document.getElementById('menu' + i).style.background = 'url('+rtc+'s07-opcOff.gif)';
		}
	}
}
function getKeyCode(event) {
		if(esTecla(UNO,event)){
			document.location.href = "/s07-tdttie/es/contenidos/prevision_tiempo/met_forecast/es_today/tdc.html";
		} else if (esTecla(DOS,event)){
			document.location.href = "/s07-tdttie/es/contenidos/prevision_tiempo/met_forecast/es_tomorrow/tdc.html";
		} else if (esTecla(TRES,event)){
			document.location.href = "/s07-tdttie/es/contenidos/prevision_tiempo/met_forecast/es_next/tdc.html";
		} else if (esTecla(CUATRO,event)){
			document.location.href = "/s07-tdttisig/es/contenidos/tendencias/met_tendency/es_today/tdc.html";
	    } else if (esTecla(AMARILLO,event)) {
			document.location.href = "/s07-tdtayu/es/contenidos/informacion/tdt_ayuda/es_ayuda/ayuda_tiempo.html";
		} else if (esTecla(VERDE,event)) {
	        document.location.href = "/s07-tdthome/eu/contenidos/informacion/tdt_home/eu_home/tdthome.html";
        } else if (esTecla(AZUL,event)) {
	        document.location.href = "/s07-tdthome/es/contenidos/informacion/tdt_home/es_home/tdthome.html";		
        } else if (esTecla(ARRIBA,event)) {
			numero= false;
			if (posicion == 0) {
			  posicion = 3;
			  carga_img(posicion);
			} else {
			  posicion = posicion - 1;
			  carga_img(posicion);
		}
        } else if (esTecla(ABAJO,event)) {
			numero = false;
			if (posicion == 3) {
			  posicion = 0;
			  carga_img(posicion);
			} else {
			  posicion = posicion + 1;
			  carga_img(posicion);
			}			
		} else if (esTecla(OK,event)) {
			if (posicion == 0) document.location.href = "/s07-tdttie/es/contenidos/prevision_tiempo/met_forecast/es_today/tdc.html";
			else if (posicion == 1) document.location.href = "/s07-tdttie/es/contenidos/prevision_tiempo/met_forecast/es_tomorrow/tdc.html";
			else if (posicion == 2) document.location.href = "/s07-tdttie/es/contenidos/prevision_tiempo/met_forecast/es_next/tdc.html";
			else if (posicion == 3) document.location.href = "/s07-tdttisig/es/contenidos/tendencias/met_tendency/es_today/tdc.html";
		}  else if (esTecla(IZQUIERDA,event) && numElem > 0){
			if (x > 1) {
				x--;
				mover_datos(false);
				document.getElementById("pag_txt").innerHTML= x + " / " + numElem;
			}
	  	} else if (esTecla(DERECHA,event) && numElem > 0){
			 if (x < numElem) {
					x++;
					mover_datos(true);
					document.getElementById("pag_txt").innerHTML= x + " / " + numElem;
			 }
		}
}

var posicion = 0;